//
//  SettingsCell.swift
//  GitHub_Project
//
//  Created by Szabo Patrik on 2022. 06. 01..
//

import UIKit

class SettingsCell: UITableViewCell {
    
    let defaults = UserDefaults.standard
    // MARK: - Create Variables and UI
    static let reuseID  = "SettingsCell"

    var sectionType: SectionType? {
        didSet{
            guard let sectionType       = sectionType else {return}
            textLabel?.text             = sectionType.description
            switchControl.isHidden      = !sectionType.containsSwitch
            
        }
    }
    
    let settingLabel = GFTitleLabel(textAlignment: .left, fontsize: 16)
    
    lazy var switchControl: UISwitch={
        switchControl                   = UISwitch()
        switchControl.isOn              = false
        switchControl.onTintColor       = .systemGreen
        switchControl.translatesAutoresizingMaskIntoConstraints = false
        switchControl.addTarget(self, action: #selector(handleSwitchAction), for: .valueChanged)
        print("switch Called")
        return switchControl
        
    }()
    // MARK: - Create Init Functions

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        configure()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Configure Layout
    private func configure(){
        addSubview(settingLabel)
        addSubview(switchControl)
        let padding = CGFloat(8)
        
        NSLayoutConstraint.activate([
        
            settingLabel.topAnchor.constraint(equalTo: topAnchor,constant: padding),
            settingLabel.leadingAnchor.constraint(equalTo: leadingAnchor,constant: padding),
            settingLabel.trailingAnchor.constraint(equalTo: trailingAnchor,constant: -padding),
            settingLabel.heightAnchor.constraint(equalToConstant: 25),
            
            switchControl.centerYAnchor.constraint(equalTo: centerYAnchor),
            switchControl.trailingAnchor.constraint(equalTo: trailingAnchor,constant: -10)
 
        ])
    
    }
    
    func set(text: String){
        settingLabel.text = text
    }
    
    func getLabelText(text: String) ->String{
        
        guard let text = settingLabel.text else {return "N/A"}
        
        return text
    }
    // MARK: - Selectors
    
    @objc func handleSwitchAction(sender: UISwitch){
        if sender.isOn {
            PersistenceManager.saveSwitchStatement(value: sender.isOn, key: sectionType?.description ?? "N/A")
        }
        else{
            PersistenceManager.saveSwitchStatement(value: sender.isOn, key: sectionType?.description ?? "N/A")
        }
    }
}
