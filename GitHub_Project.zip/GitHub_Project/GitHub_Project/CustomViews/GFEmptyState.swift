//
//  GFEmptyState.swift
//  GitHub_Project
//
//  Created by Szabo Patrik on 2022. 05. 22..
//

import UIKit

class GFEmptyState: UIView {
    
    let messageLabel = GFTitleLabel(textAlignment: .center, fontsize: 28)
    let logoImage = UIImageView()

    override init(frame: CGRect) {
        super.init(frame: frame)
        configure()
    }
    
    
    
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    init(message: String){
        super.init(frame: .zero)
        messageLabel.text = message
        configure()
    }
    
    
    private func configure(){
        addSubview(logoImage)
        addSubview(messageLabel)
        
        messageLabel.numberOfLines = 3
       
        
        messageLabel.textColor = .label
        
        logoImage.image = UIImage(named: "empty-state-logo")
        logoImage.contentMode = .scaleAspectFit
        logoImage.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            messageLabel.topAnchor.constraint(equalTo: self.safeAreaLayoutGuide.topAnchor),
                messageLabel.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 40),
                messageLabel.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -40),
                messageLabel.heightAnchor.constraint(equalToConstant: 200),

                logoImage.widthAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1.3),
                logoImage.heightAnchor.constraint(equalTo: self.widthAnchor, multiplier: 1.3),
                logoImage.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: 200),
            logoImage.bottomAnchor.constraint(equalTo: self.safeAreaLayoutGuide.bottomAnchor, constant: 40)
        ])
    
        
    }
    
}
