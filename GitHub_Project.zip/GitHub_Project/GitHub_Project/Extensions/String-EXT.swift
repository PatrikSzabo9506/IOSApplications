//
//  String-EXT.swift
//  GitHub_Project
//
//  Created by Szabo Patrik on 2022. 05. 24..
//

import Foundation

extension String{
    // change a string to Date
    func convertToDate() -> Date? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
        dateFormatter.locale = Locale(identifier: "en_GB")
        dateFormatter.timeZone = .current
        return dateFormatter.date(from: self)!
    }
    
    //convert the Date back to string with display format
    func convertToDisplayFormat() -> String{
        
        guard let date = self.convertToDate()
        else {return "N/A"}
        return date.convertToMonthYearFormat()
    }
}
