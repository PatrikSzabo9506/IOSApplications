//
//  Date+EXT.swift
//  GitHub_Project
//
//  Created by Szabo Patrik on 2022. 05. 24..
//

import Foundation

extension Date{
    
    // change the date to string like "Oct 2006"
    func convertToMonthYearFormat() -> String {
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "MMM yyyy"
        
        
        return dateformatter.string(from: self)
        
    }
    
}
