//
//  Constants.swift
//  GitHub_Project
//
//  Created by Szabo Patrik on 2022. 05. 23..
//

import Foundation


enum SFSymbols{
    // Use this symbols to not been hardcoded
    static let location     = "mappin.and.ellipse"
    static let folder       = "folder"
    static let gists        = "text.alignleft"
    static let follower     = "heart"
    static let following    = "person.2"
    
}
