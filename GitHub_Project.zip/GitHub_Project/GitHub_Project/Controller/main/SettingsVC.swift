//
//  SettingsVC.swift
//  GitHub_Project
//
//  Created by Szabo Patrik on 2022. 06. 01..
//

import UIKit

class SettingsVC: UIViewController {
    
    let settingsView = UITableView()
    
    
   
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        navigationController?.navigationBar.prefersLargeTitles = true
        configureTableView()
        
    }
    
    private func reloadData(){
        
    }
    
    func configureTableView(){
        view.addSubview(settingsView)
        settingsView.frame = view.bounds
        settingsView.rowHeight = 30
        settingsView.delegate = self
        settingsView.dataSource = self
        settingsView.register(SettingsCell.self, forCellReuseIdentifier: SettingsCell.reuseID)
    }
}

extension SettingsVC: UITableViewDelegate,UITableViewDataSource{

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let section = SettingsSection.init(rawValue: section) else {return 0}
        switch section {
        case .social:
            return SocialActions.allCases.count
        case .communications:
            return CommunicationActions.allCases.count
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return SettingsSection.allCases.count
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let view = UIView()
        view.backgroundColor = .systemGreen
        
        let title = UILabel()
        title.font = UIFont.boldSystemFont(ofSize: 16)
        title.textColor = .white
        view.addSubview(title)
        title.translatesAutoresizingMaskIntoConstraints = false
        title.text = SettingsSection.init(rawValue: section)?.description
        
        NSLayoutConstraint.activate([
            title.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            title.leadingAnchor.constraint(equalTo: view.leadingAnchor,constant: 12)
        
        
        ])
        
        return view
        
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       let cell = tableView.dequeueReusableCell(withIdentifier: SettingsCell.reuseID) as! SettingsCell
  //      let setting = settings[indexPath.row]
  //      cell.set(text: setting)
        guard let section = SettingsSection.init(rawValue:indexPath.section) else {return UITableViewCell()}
        
        switch section {
        case .social:
            let social = SocialActions(rawValue: indexPath.row)
            cell.sectionType = social
        case .communications:
            let communications = CommunicationActions(rawValue: indexPath.row)
            cell.sectionType = communications
            cell.switchControl.isOn = PersistenceManager.retriveSwitchStatement(forKey: communications?.description ?? "N/A")
        
            
        }
    
        
        cell.contentView.isUserInteractionEnabled = false
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    

    
}
