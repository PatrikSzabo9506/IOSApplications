//
//  UserInfoVC.swift
//  GitHub_Project
//
//  Created by Szabo Patrik on 2022. 05. 23..
//

import UIKit

protocol UserInfoVCDelegate: AnyObject{
    func didTapGuthubProfile(for user: User)
    func didTapGetFollowers(for user: User)
}

class UserInfoVC: UIViewController {
    
    var username: String!
    let headerView = UIView()
    let itemView1 = UIView()
    let itemView2 = UIView()
    let dateLabel = GFBodyLabel(textAlignment: .center)
    
    weak var delegate: FollowerListVCDelegate!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .systemBackground
        configureViewController()
        layoutUI()
        getUser()
        
    }
    
    func configureViewController(){
        let doneButton = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(dismissVC))
        navigationItem.rightBarButtonItem = doneButton
    }
    
    func getUser(){
        NetworkManager.shared.getUser(username: username) { [weak self] result in
            guard let self = self else {return}
            
            switch result{
            case .success(let user):
                DispatchQueue.main.async {
                    self.configureUIElementsWithUser(user: user)
                }
                
            case .failure(let error):
                self.presentGFAlertOnMainThread(title: "Something went wrong", message: error.rawValue, buttonTitle: "ok")
            }
            
        }
    }
    
    func configureUIElementsWithUser(user:User){
        
        let repoItemVC = GFReposVC(user: user)
        repoItemVC.delegate = self
        
        let followerVC = GFFollowersVC(user: user)
        followerVC.delegate = self
        
        self.addChildVC(childVC: GFUserInfoHeaderVC(user: user), to: self.headerView)
        self.addChildVC(childVC: followerVC, to: self.itemView2)
        self.addChildVC(childVC: repoItemVC,  to: self.itemView1)
        self.dateLabel.text = "Github Since \(user.createdAt.convertToDisplayFormat())"
    }
    
    func layoutUI(){
        
        let padding = CGFloat(20)
        let itemHeight = CGFloat(140)
        let items = [headerView,itemView1,itemView2,dateLabel]
     
        
        for item in items{
            view.addSubview(item)
            item.translatesAutoresizingMaskIntoConstraints = false
           
            
            NSLayoutConstraint.activate([
                item.leadingAnchor.constraint(equalTo: view.leadingAnchor,constant: padding),
                item.trailingAnchor.constraint(equalTo: view.trailingAnchor,constant: -padding)
            ])
        }

        NSLayoutConstraint.activate([
            
            headerView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            headerView.heightAnchor.constraint(equalToConstant: 180),
            
            itemView1.topAnchor.constraint(equalTo: headerView.bottomAnchor,constant: padding),
            itemView1.heightAnchor.constraint(equalToConstant: itemHeight),
            
            itemView2.topAnchor.constraint(equalTo: itemView1.bottomAnchor,constant: padding),
            itemView2.heightAnchor.constraint(equalToConstant: itemHeight),
            
            dateLabel.heightAnchor.constraint(equalToConstant: 20),
            dateLabel.topAnchor.constraint(equalTo: itemView2.bottomAnchor,constant: 5)
        ])
    }
    
    func addChildVC(childVC: UIViewController,to containerView: UIView){
        //Start ez teszi lehetővé hogy egy viewController kitöltse a helyet egy view-ban
        
        addChild(childVC)
        containerView.addSubview(childVC.view)
        childVC.view.frame = containerView.bounds
        childVC.didMove(toParent: self)
        // end
    }
    
    @objc func dismissVC(){
        dismiss(animated: true)
    }
    
    
    func configureDateLabel(){
        
       
    }
    
    
}
extension UserInfoVC: UserInfoVCDelegate{
    func didTapGuthubProfile(for user: User) {
        guard let url = URL(string: user.htmlUrl) else{presentGFAlertOnMainThread(title: "Url wrong", message: "Can't reach the URL", buttonTitle: "Ok")
            return
        }
        
        
        getSafariPageWithUrl(from: url)
        
       
    }
    
    func didTapGetFollowers(for user: User) {
        
        if user.followers != 0{
        delegate.didRequestFollowers(for: user.login)
            dismissVC()
        }
        else{
            presentGFAlertOnMainThread(title: "Followers", message: "No followers", buttonTitle: "Ok")
        }
    }
    
    
    
    
}
