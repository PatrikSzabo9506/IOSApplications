//
//  SearchVC.swift
//  GitHub_Project
//
//  Created by Szabo Patrik on 2022. 05. 16..
//

import UIKit

class SearchVC: UIViewController {
    
    let logoImageView = UIImageView()
    
    let usernameTextField = GFTextField()
    let actionButton = GFButton(backgroundColor: .systemGreen, title: "Get Followers")
    
    var isUsernameEntered: Bool {
        return !usernameTextField.text!.isEmpty
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .systemBackground
        configureLogoImageView()
        configureTextField()
        configureCallToActionButton()
        createDismissKeyboardAction()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: true) 
    }
    
    
    
    @objc func pushFollowerListVC(){
        guard  isUsernameEntered else {
            
            presentGFAlertOnMainThread(title: "Empty UserName", message: "Please enter a username we need to kno who to look for 😀", buttonTitle: "Accept")
            return}
        
        let followerVC = FollowerVC()
        followerVC.username = usernameTextField.text
        followerVC.title = usernameTextField.text
        
        
        navigationController?.pushViewController(followerVC, animated: true)
    }
    
    
    func configureLogoImageView(){
        view.addSubview(logoImageView)
        
        logoImageView.translatesAutoresizingMaskIntoConstraints = false
        logoImageView.image = UIImage(named: "gh-logo")!
        
        NSLayoutConstraint.activate([
        
            logoImageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor,constant: 80),
            logoImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            logoImageView.heightAnchor.constraint(equalToConstant: 200),
            logoImageView.widthAnchor.constraint(equalToConstant: 200)
        
        
        
        
        
        ])
        
    }
    
    func configureTextField(){
        view.addSubview(usernameTextField)
        usernameTextField.delegate = self
        
        NSLayoutConstraint.activate([
            usernameTextField.topAnchor.constraint(equalTo: logoImageView.bottomAnchor,constant: 48),
            usernameTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor,constant: 50),
            usernameTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor,constant: -50),
            usernameTextField.heightAnchor.constraint(equalToConstant: 50)
            
        
        ])
        
    }
    
    func configureCallToActionButton(){
        
        view.addSubview(actionButton)
        
        NSLayoutConstraint.activate([
            actionButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor ,constant: -100),
            actionButton.leadingAnchor.constraint(equalTo: view.leadingAnchor,constant: 50),
            actionButton.trailingAnchor.constraint(equalTo: view.trailingAnchor,constant: -50),
            actionButton.heightAnchor.constraint(equalToConstant: 50)
        
        
        ])
        
        
        actionButton.addTarget(self, action: #selector(pushFollowerListVC), for: .touchUpInside)
        
    }
   

    func createDismissKeyboardAction(){
        
        let tap = UITapGestureRecognizer(target: self.view, action: #selector(UIView.endEditing(_:)))
        
     
        view.addGestureRecognizer(tap)
        
      //  pushFollowerListVC()
        
        
    }
    
}
