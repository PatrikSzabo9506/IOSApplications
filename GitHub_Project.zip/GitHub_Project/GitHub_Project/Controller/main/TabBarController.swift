//
//  TabBarController.swift
//  GitHub_Project
//
//  Created by Szabo Patrik on 2022. 05. 22..
//

import UIKit

class TabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        UITabBar.appearance().tintColor = .systemGreen
        viewControllers = [crateSearchNavigationController(),crateFavoriteNavigationController(),createSettingsNavigationController()]
    }
    
    func crateSearchNavigationController() -> UINavigationController{
        
        let searchVC = SearchVC()
        searchVC.title = "Search"
        searchVC.tabBarItem = UITabBarItem(tabBarSystemItem: .search, tag: 0)
        
        return UINavigationController(rootViewController: searchVC)
        
    }
    
    func crateFavoriteNavigationController() -> UINavigationController{
        
        let favoriteVC = FavoriteVC()
        favoriteVC.title = "Favorites"
        favoriteVC.tabBarItem = UITabBarItem(tabBarSystemItem: .favorites, tag: 1)
        
        return UINavigationController(rootViewController: favoriteVC)
    }
    
    func createSettingsNavigationController() -> UINavigationController{
        let settingsVC = SettingsVC()
        settingsVC.title = "Settings"
        settingsVC.tabBarItem = UITabBarItem(title: "Settings", image: UIImage(systemName: "gear.circle"), tag: 2)
        
        return UINavigationController(rootViewController: settingsVC)
    }
    
    func createTabBar() -> UITabBarController{
        
        let tabBar = UITabBarController()
       
        
        
        return tabBar
        
    }
}
