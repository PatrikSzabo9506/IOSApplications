//
//  FollowerVC.swift
//  GitHub_Project
//
//  Created by Szabo Patrik on 2022. 05. 17..
//

import UIKit

protocol FollowerListVCDelegate: AnyObject{
    func didRequestFollowers(for username: String)
    
}

class FollowerVC: UIViewController {
    
    enum Section{
        case main
    }
    
    var username: String!
    var collectionView: UICollectionView!
    var dataSource : UICollectionViewDiffableDataSource<Section,Follower>!
    var followers: [Follower] = []
    var page = 1
    var hasMoreFollowers = true
    var filteredFollowers: [Follower] = []
    var isSearching = false
    let profileImage = AvatarImageProfileView(frame: .zero)
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        configureCollectionView()
        configureSearchController()
        getFollowers(username: username, page: page)
        configureDataSourcse()
        configureViewController()
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        navigationController?.setNavigationBarHidden(false, animated: true)
    }
    
    func configureProfileImage(){
        view.addSubview(profileImage)
        profileImage.
    }
    
    func configureSearchController(){
        let searchController                        = UISearchController()
        searchController.searchResultsUpdater       = self
        searchController.searchBar.delegate         = self
        searchController.searchBar.placeholder      = "Search follower"
        navigationItem.searchController             =  searchController
        navigationItem.hidesSearchBarWhenScrolling  = false
    }
    
    
    
    func configureCollectionView(){
        collectionView = UICollectionView(frame: view.bounds, collectionViewLayout: UIHelper.create3FollowerLayout(in: view))
        collectionView.delegate = self
        
        view.addSubview(collectionView)
        collectionView.backgroundColor = .systemBackground
        
        collectionView.register(FollowerCell.self, forCellWithReuseIdentifier: FollowerCell.reuseID)
    }
    
    
    func configureViewController(){
        
        view.backgroundColor = .systemBackground
        
        navigationController?.navigationBar.prefersLargeTitles = true
        
        
        let addButton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addButtonTapped))
        navigationItem.rightBarButtonItem = addButton
        
        
        
    }
    
    func getFollowers(username: String, page: Int){
        
        showLoadingView()
        NetworkManager.shared.getFollowers(username: username, page: page) {[weak self] result in
            
            guard let self = self else{return}
            //Dismiss the loading view
            self.dismissLoadingView()
            switch result{
            case .success(let followers):
                if followers.count < 100  {
                    self.hasMoreFollowers = false
                    
                }
                
                self.followers.append(contentsOf: followers)
                if self.followers.isEmpty{
                    let message = "This user don't have any followers. Go Follow them"
                    DispatchQueue.main.async {
                        self.showEmptyView(with: message, in: self.view)
                    }
                    return
                }
                self.updateData(on: self.followers)
                
            case .failure(let error):
                self.presentGFAlertOnMainThread(title: "Bad Stuf", message: error.rawValue, buttonTitle: "Ok")
                
            }
            
        }
        
    }
    
    func configureDataSourcse(){
        dataSource = UICollectionViewDiffableDataSource<Section,Follower>(collectionView: collectionView, cellProvider: { collectionView, indexPath, follower in
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: FollowerCell.reuseID, for: indexPath) as! FollowerCell
            cell.set(follower: follower)
            
            
            return cell
        })
    }
    
    
    func updateData(on followers:[Follower]){
        var snapshot = NSDiffableDataSourceSnapshot<Section,Follower>()
        snapshot.appendSections([.main])
        snapshot.appendItems(followers)
        
        DispatchQueue.main.async {
            self.dataSource.apply(snapshot,animatingDifferences: true)
        }
    }
    
    @objc func addButtonTapped(){
        showLoadingView()
        
        NetworkManager.shared.getUser(username: username) {[weak self] result in
            
            guard let self = self else {return}
            
            self.dismissLoadingView()
            print("inside the network call")
            switch result{
            case .success(let user):
                let follower = Follower(login: user.login, avatarUrl: user.avatarUrl)
                print(follower)
                PersistenceManager.updateWith(favorite: follower, actionType: .add) {[weak self] error in
                    guard let self = self  else {return}
                    guard let error = error else{
                        self.presentGFAlertOnMainThread(title: "Added", message: "You added a new user for your favorites", buttonTitle: "Hoooreeey!")
                        return
                    }
                    self.presentGFAlertOnMainThread(title: "Something wrong", message: error.rawValue, buttonTitle: "Ok :/")
                }

            case .failure(let error):
                self.presentGFAlertOnMainThread(title: "Wrong", message: error.rawValue, buttonTitle: "I understand")
            }
        }
    }
}

extension FollowerVC: UICollectionViewDelegate{
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        let offsetY          = scrollView.contentOffset.y
        let contentHeight    = scrollView.contentSize.height
        let height           = scrollView.frame.size.height
        
        print(offsetY)
        print(contentHeight)
        print(height)
        print(contentHeight - height)
        
        if offsetY > contentHeight - height
        {
            guard hasMoreFollowers else {return}
            page = page + 1
            getFollowers(username: username, page: page)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let activeArray = isSearching ? filteredFollowers : followers
        
        let follower = activeArray[indexPath.item]
        let destVC = UserInfoVC()
        destVC.delegate = self
        destVC.username = follower.login
        let navVC = UINavigationController(rootViewController: destVC)
        present(navVC, animated: true)
        
    }
}

extension FollowerVC: UISearchResultsUpdating, UISearchBarDelegate{
    func updateSearchResults(for searchController: UISearchController) {
        
        guard let filter = searchController.searchBar.text, !filter.isEmpty else {return}
        
        filteredFollowers    = followers.filter{$0.login.lowercased().contains(filter.lowercased()) }
        isSearching          = true
        updateData(on: filteredFollowers)
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        isSearching = false
        updateData(on: followers)
    }
}

extension FollowerVC:FollowerListVCDelegate{
    func didRequestFollowers(for username: String) {
        self.username   = username
        title           = username
        followers.removeAll()
        filteredFollowers.removeAll()
        page            = 1
        collectionView.setContentOffset(.zero, animated: true)
        getFollowers(username: username, page: page)
    }
    
    
}

