//
//  GFItemInfoVC.swift
//  GitHub_Project
//
//  Created by Szabo Patrik on 2022. 05. 24..
//

import UIKit

class GFItemInfoVC: UIViewController {

    let stackView = UIStackView()
    let itemInfoView1 = GFItemInfoView()
    let itemInfoView2 = GFItemInfoView()
    let actionButton1 = GFButton()
    
  weak  var delegate: UserInfoVCDelegate!
    
    var user: User!
    
    init(user:User) {
        super.init(nibName: nil, bundle: nil)
        self.user = user
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureBackgroundView()
        layoutUI()
        configureStackView()
        configureActionButton()

        
    }
    
    func configureBackgroundView(){
        view.layer.cornerRadius = 18
        view.backgroundColor = .secondarySystemBackground
        
    }
    
  private  func layoutUI(){
        
      view.addSubview(stackView)
      
      view.addSubview(actionButton1)
      
      stackView.translatesAutoresizingMaskIntoConstraints = false
      let padding: CGFloat = 20
      
      NSLayoutConstraint.activate([
        
        stackView.topAnchor.constraint(equalTo: view.topAnchor,constant: padding),
        stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor,constant: padding),
        stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor,constant: -padding),
        stackView.heightAnchor.constraint(equalToConstant: 50),
        
        actionButton1.bottomAnchor.constraint(equalTo: view.bottomAnchor,constant: -padding),
        actionButton1.leadingAnchor.constraint(equalTo: view.leadingAnchor,constant: padding),
        actionButton1.trailingAnchor.constraint(equalTo: view.trailingAnchor,constant: -padding),
        actionButton1.heightAnchor.constraint(equalToConstant: 50)
        
      ])
      
      
  }
    
    private func configureStackView(){
        stackView.axis = .horizontal
        
        stackView.distribution = .equalSpacing
        
        stackView.addArrangedSubview(itemInfoView1)
        stackView.addArrangedSubview(itemInfoView2)
    }
    
    
    private func configureActionButton(){
        actionButton1.addTarget(self, action: #selector(actionButtonTapped), for: .touchUpInside)
    }
    
   @objc func actionButtonTapped(){
        
    }

}
