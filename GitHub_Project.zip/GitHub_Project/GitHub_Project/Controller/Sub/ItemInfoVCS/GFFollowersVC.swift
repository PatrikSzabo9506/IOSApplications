//
//  GFRepoItemVC.swift
//  GitHub_Project
//
//  Created by Szabo Patrik on 2022. 05. 24..
//

import UIKit

class GFFollowersVC: GFItemInfoVC{
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureItems()
    }
    
    private func configureItems(){
        itemInfoView1.setItemInfoType(itemInfoType: .followers, with: user.followers)
        itemInfoView2.setItemInfoType(itemInfoType: .following, with: user.following)
        actionButton1.setBackground(backGroundColor: .systemGreen, title: "Get followers")
    }
    
   
    override func actionButtonTapped() {
        delegate.didTapGetFollowers(for: user)
    }
}
