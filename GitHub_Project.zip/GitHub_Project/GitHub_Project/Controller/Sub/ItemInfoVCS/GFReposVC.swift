//
//  GFFollowerItemVC.swift
//  GitHub_Project
//
//  Created by Szabo Patrik on 2022. 05. 24..
//

import UIKit

class GFReposVC: GFItemInfoVC{
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureItems()
        
    }
    private func configureItems(){
        itemInfoView1.setItemInfoType(itemInfoType: .repos, with: user.publicRepos)
        itemInfoView2.setItemInfoType(itemInfoType: .gists, with: user.publicGists)
        actionButton1.setBackground(backGroundColor: .systemPurple, title: "Github Profile")
    }
    
    override func actionButtonTapped() {
        delegate.didTapGuthubProfile(for:user)
    }
    
}
