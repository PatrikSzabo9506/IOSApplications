//
//  SettingsModel.swift
//  GitHub_Project
//
//  Created by Szabo Patrik on 2022. 06. 01..
//


protocol SectionType: CustomStringConvertible {
    var containsSwitch: Bool {get}
}


enum SettingsSection: Int,CaseIterable,CustomStringConvertible{
    case social
    case communications
    
    var description:String{
        switch self {
        case .social:
            return "Social"
        case .communications:
            return "Communications"
        }
    }
}

enum SocialActions:Int,CaseIterable,SectionType{
    case editProfile
    case logOut
    
    var containsSwitch: Bool{
        return false
    }
    
    var description:String {
        switch self {
        case .editProfile:
            return "Edit profile"
        case .logOut:
            return "Log Out"
        }
    }

}
enum CommunicationActions:Int,CaseIterable,SectionType{
  
    case notifications
    case email
    case reportCrashes
    case DarkMode
    
    var containsSwitch: Bool{
        switch self {
        case .notifications:
            return true
        case .email:
            return true
        case .reportCrashes:
            return false
        case .DarkMode:
            return true
        }
    }
    
    var description: String{
        switch self {
        case .notifications:
            return "Notifications"
        case .email:
            return "Email"
        case .reportCrashes:
            return "Report Crashes"
        case.DarkMode:
            return "Change to Dark Mode"
        }
        
    }
      
}
