//
//  Follower.swift
//  GitHub_Project
//
//  Created by Szabo Patrik on 2022. 05. 18..
//

import Foundation

struct Follower: Codable, Hashable {
    var login: String
    var avatarUrl: String
}
