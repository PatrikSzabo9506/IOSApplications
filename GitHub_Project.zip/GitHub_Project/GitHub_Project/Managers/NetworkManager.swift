//
//  NetworkManager.swift
//  GitHub_Project
//
//  Created by Szabo Patrik on 2022. 05. 18..
//


import UIKit

class NetworkManager{
    
    
   static let shared = NetworkManager()
    
  private  let baseURL = "https://api.github.com/users/"
    let cache = NSCache<NSString,UIImage>()
    private init(){}
    
    
    func getFollowers(username:String,page:Int,completed:@escaping (Result<[Follower], GFError>) -> Void)  {
        let endPoint = baseURL + "\(username)/followers?per_page=100&page=\(page)"
        
        guard let url = URL(string: endPoint) else{
            completed(.failure(.invalidUsername))
            return
             }
        
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            if let _ = error{
                
                completed(.failure(.unableToComplete))
                
            }
            
            guard let response = response as? HTTPURLResponse, response.statusCode == 200   else{
                
                completed(.failure(.invalidRespone))
                return
            }
            
            guard let safeData = data else{
                
                completed(.failure(.dataReceiveError))
                return
            }
            
            do{
                
                let decoder = JSONDecoder()
                decoder.keyDecodingStrategy = .convertFromSnakeCase
                let followers = try decoder.decode([Follower].self, from: safeData)
                
                completed(.success(followers))
                
                
            }catch{
                completed(.failure(.dataReceiveError))
            }
            
        }
        
        task.resume()
    }
    
    
    func getUser(username:String,completed:@escaping (Result<User, GFError>) -> Void)  {
        let endPoint = baseURL + "\(username)"
        
        guard let url = URL(string: endPoint) else{
            completed(.failure(.invalidUsername))
            return
             }
        
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            if let _ = error{
                
                completed(.failure(.unableToComplete))
                
            }
            
            guard let response = response as? HTTPURLResponse, response.statusCode == 200   else{
                
                completed(.failure(.invalidRespone))
                return
            }
            
            guard let safeData = data else{
                
                completed(.failure(.dataReceiveError))
                return
            }
            
            do{
                
                let decoder = JSONDecoder()
                decoder.keyDecodingStrategy = .convertFromSnakeCase
                let user = try decoder.decode(User.self, from: safeData)
                
                completed(.success(user))
                
                
            }catch{
                completed(.failure(.dataReceiveError))
            }
            
        }
        
        task.resume()
    }
    
    
}
