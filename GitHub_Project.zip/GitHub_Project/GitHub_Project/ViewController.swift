//
//  ViewController.swift
//  GitHub_Project
//
//  Created by Szabo Patrik on 2022. 05. 15..
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemPink
    }


}

