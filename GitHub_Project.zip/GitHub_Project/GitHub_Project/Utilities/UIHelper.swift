//
//  UIHelper.swift
//  GitHub_Project
//
//  Created by Szabo Patrik on 2022. 05. 18..
//

import UIKit

struct UIHelper{
    
    // use this function to create the size of the collectionView
   static func create3FollowerLayout(in view: UIView) -> UICollectionViewFlowLayout{
        
        let width                = view.bounds.width
        let padding              = CGFloat(12)
        let minimumItemSpacing   = CGFloat(10)
        
        let availableWidth       = width - (padding * 2) - (minimumItemSpacing * 2)
        let itemWidth            = availableWidth/3
        
        let flowLayout           = UICollectionViewFlowLayout()
        flowLayout.sectionInset  = UIEdgeInsets(top: padding, left: padding, bottom: padding, right: padding)
        flowLayout.itemSize      = CGSize(width: itemWidth, height: itemWidth + 40)
        
        
        return flowLayout
        
    }
}
