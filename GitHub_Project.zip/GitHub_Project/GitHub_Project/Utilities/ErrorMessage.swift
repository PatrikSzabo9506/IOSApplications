//
//  ErrorMessage.swift
//  GitHub_Project
//
//  Created by Szabo Patrik on 2022. 05. 18..
//

import Foundation

enum GFError: String, Error{
    // use this error messages to fill Network call with Pop Up messages
    case invalidUsername     = "The username was not valid"
    case unableToComplete    = "Unable to complete your request"
    case invalidRespone      = "Invalid Response from the server"
    case dataReceiveError    = "Can't reach the data from the server"
    case unableToFavorites   = "Can't reach the Favorites please try again"
    case duplication         = "This user is already in your list"
}
