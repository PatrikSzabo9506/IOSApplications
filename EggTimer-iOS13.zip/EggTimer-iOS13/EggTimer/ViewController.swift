//
//  ViewController.swift
//  EggTimer
//
//  Created by Angela Yu on 08/07/2019.
//  Copyright © 2019 The App Brewery. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    
    var player: AVAudioPlayer!

    var eggTime = ["Hard":3, "Soft":5, "Medium": 7]
    
    var totalTime = 0
    var secondsPassed = 0
    var time = Timer()
  
    @IBOutlet weak var barProgress: UIProgressView!
    
    @IBOutlet weak var labelView: UILabel!
    
    @IBAction func eggPressed(_ sender: UIButton) {
        
        time.invalidate()
        barProgress.progress = 0.0
        secondsPassed = 0
       
        
        let hardness = sender .currentTitle!
       
        labelView.text = hardness
       // print(eggTime[hardness]!)
        
        totalTime = eggTime[hardness]!
        
      time = Timer.scheduledTimer(timeInterval: 1.0,target: self, selector: #selector(updateTimer), userInfo: nil, repeats: true)
    
    }
    
    @objc func updateTimer(){
        if secondsPassed < totalTime {
            
            secondsPassed += 1
            
            let secondProgress = Float(Float(secondsPassed) / Float(totalTime))
            barProgress.progress = secondProgress
            
            if barProgress.progress == 1.0 {
                playSound()
            }
            
           
        }
        else{
            time.invalidate()
            labelView.text = "Done !"
            
            
            
            
        }
    }
    
    func playSound() {
        
    
        
        let url = Bundle.main.url(forResource: "alarm_sound", withExtension: "mp3")
        player = try! AVAudioPlayer(contentsOf: url!)
        player.play()
                
    }
    
    
    
    
}
