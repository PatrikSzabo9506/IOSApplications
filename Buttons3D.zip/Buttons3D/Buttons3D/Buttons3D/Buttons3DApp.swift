//
//  Buttons3DApp.swift
//  Buttons3D
//
//  Created by Patrik Szabo on 2021. 07. 01..
//

import SwiftUI

@main
struct Buttons3DApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
