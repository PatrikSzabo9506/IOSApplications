//
//  ContentView.swift
//  BasicStarWarsApp
//
//  Created by Patrik Szabo on 2021. 07. 02..
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView{
            ZStack{
                Color.black
                VStack{
                    Spacer()
                    
                    Image("star_wars")
                        .resizable()
                        .frame(width: 200, height: 100)
                    
                    Spacer()
                    
                    
                    
                    NavigationLink(
                        destination: ChoosenView(),
                        label: {
                            Text("Choose one side")
                                .bold()
                                .font(.title2)
                                .frame(width: 280, height: 50)
                                .background(LinearGradient(gradient: Gradient(colors: [Color.gray, Color(#colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1))]), startPoint: .topLeading, endPoint: .bottomTrailing))
                                .foregroundColor(.white)
                                .cornerRadius(10)
                        })
                    
                    
                    
                    
                    
                    
                    
                    
                    Spacer()
                    
                }
            }.edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            
            
        }
        
        
        
        
        
        
        
        
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
