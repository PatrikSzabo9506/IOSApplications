//
//  BasicStarWarsAppApp.swift
//  BasicStarWarsApp
//
//  Created by Patrik Szabo on 2021. 07. 02..
//

import SwiftUI

@main
struct BasicStarWarsAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
