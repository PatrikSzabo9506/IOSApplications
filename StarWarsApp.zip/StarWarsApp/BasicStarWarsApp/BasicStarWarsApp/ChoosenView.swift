//
//  ChoosenView.swift
//  BasicStarWarsApp
//
//  Created by Patrik Szabo on 2021. 07. 02..
//

import SwiftUI

struct ChoosenView: View {
    var body: some View {
        ZStack{
            Color.black
            
            VStack{
                Text("Choose one")
                    .foregroundColor(.white)
                    .padding(20)
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    
                
                HStack(spacing: 30){
                    
                    
                    VStack{
                    Image("rebels")
                        .resizable()
                        .frame(width: 200, height: 70)
                   

                    }
                    
                    Image("empire")
                        .resizable()
                        .frame(width: 200, height: 70)
                        .background(Color(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)))
                    
                }
                
            }
            
        }.edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
    }
}

struct ChoosenView_Previews: PreviewProvider {
    static var previews: some View {
        ChoosenView()
    }
}
