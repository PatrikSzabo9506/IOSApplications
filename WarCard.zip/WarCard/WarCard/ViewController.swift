//
//  ViewController.swift
//  WarCard
//
//  Created by Patrik Szabo on 2021. 05. 09..
//

import UIKit

class ViewController: UIViewController {
    
    
    
    @IBOutlet weak var leftImageView: UIImageView!
    
    
    @IBOutlet weak var rightImageView: UIImageView!
    

    @IBOutlet weak var leftScoreLabel: UILabel!
    
    
    @IBOutlet weak var rightScoreLabel: UILabel!
    
    var playerScore = 0
     var computerScore = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    
    
    @IBAction func dealTappaed(_ sender: Any) {
        
        //Rondomize the card of pick left
        let leftNumber = Int.random(in: 2...14)
        //randomize the card of pick in right side
        let rightNumber = Int.random(in: 2...14)
       
        //change the card image in left side
        leftImageView.image = UIImage(named: "card\(leftNumber)")
        //change the card image in right side
        rightImageView.image = UIImage(named: "card\(rightNumber)")
        
      
       
        if leftNumber>rightNumber {
            //if left card is bigger
        playerScore += 1
            leftScoreLabel.text = String(playerScore)
        }
        
        else if leftNumber<rightNumber
        {
            //if right card is bigger
            computerScore += 1
            
            rightScoreLabel.text = String(computerScore)
        }
        
    }
    
    
    
    
}

