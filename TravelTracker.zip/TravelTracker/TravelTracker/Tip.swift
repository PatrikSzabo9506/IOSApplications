//
//  Tip.swift
//  TravelTracker
//
//  Created by Patrik Szabo on 2021. 05. 18..
//

import Foundation

struct Tip: Decodable{
    let text: String
    let children:[Tip]?
        
    
}
