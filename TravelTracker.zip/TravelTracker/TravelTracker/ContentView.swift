//
//  ContentView.swift
//  TravelTracker
//
//  Created by Patrik Szabo on 2021. 05. 17..
//

import SwiftUI

struct ContentView: View {
    
  let  location: Location
    
    var body: some View {
        ScrollView
        {
        
            Image(location.heroPicture)
            .resizable().scaledToFit()
            Text(location.name)
                .font(.largeTitle).bold()
                .multilineTextAlignment(.center)
            Text(location.country).font(.title).foregroundColor(.secondary)
            
            Text(location.description ).padding(.horizontal)
            
            Text("Did you know? ").font(.title3).bold().padding(.top)
            
            
            Text(location.more).navigationTitle("Discover").padding(.horizontal)
            
            
        }
        
        }
        
        
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(location: Location.example)
    }
}
