//
//  HackerNewsReader_SwiftUIApp.swift
//  HackerNewsReader_SwiftUI
//
//  Created by Patrik Szabo on 2021. 11. 03..
//

import SwiftUI

@main
struct HackerNewsReader_SwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
