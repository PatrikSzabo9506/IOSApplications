//
//  ContentView.swift
//  HackerNewsReader_SwiftUI
//
//  Created by Patrik Szabo on 2021. 11. 03..
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject var networkManager = NetworkManager()
    
    var body: some View {
        
        NavigationView{
            
            List(networkManager.posts){post in
                NavigationLink(destination: DetailView(url: post.url), label: {
                    HStack{
                        Text(String(post.points))
                        Text(post.title)
                    }
                })
                
                
                
            }
            .navigationTitle("H4X0R NEWS")
        }
        .onAppear {
            self.networkManager.fetchData()
        }
        
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}



