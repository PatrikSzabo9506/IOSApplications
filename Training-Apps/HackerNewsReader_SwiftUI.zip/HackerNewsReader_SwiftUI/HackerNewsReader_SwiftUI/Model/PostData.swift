//
//  PostData.swift
//  HackerNewsReader_SwiftUI
//
//  Created by Patrik Szabo on 2021. 11. 15..
//

import Foundation


struct Results: Decodable{
    var hits: [Post]
    
    
}


struct Post: Codable, Identifiable{
    
    var objectID: String
    var id: String{
        return objectID
    }
    
    var title: String
    var points: Int
    var url: String?
}
