//
//  ViewController.swift
//  Tipsy
//
//  Created by Angela Yu on 09/09/2019.
//  Copyright © 2019 The App Brewery. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var person = 0.0
    var cost: Float = 0
    var finishCost: Float = 0.0
   
    var costBrain = CostBrain()

    @IBOutlet weak var billTextField: UITextField!
    @IBOutlet weak var zeroPercentTipButton: UIButton!
    @IBOutlet weak var tenPercentTipButton: UIButton!
    @IBOutlet weak var twentyPercentTipButton: UIButton!
    @IBOutlet weak var splitNumberLabel: UILabel!
    
  

    @IBAction func tipChanged(_ sender: UIButton) {
        if zeroPercentTipButton.isTouchInside{
            zeroPercentTipButton.isSelected = true
            tenPercentTipButton.isSelected = false
            twentyPercentTipButton.isSelected = false
            costBrain.setTips(tip: 0.0)
        }
        else if tenPercentTipButton.isTouchInside {
            tenPercentTipButton.isSelected = true
            zeroPercentTipButton.isSelected = false
            twentyPercentTipButton.isSelected = false
            
            costBrain.setTips(tip: 0.1)
            
            }
        
        else{
            twentyPercentTipButton.isSelected = true
            zeroPercentTipButton.isSelected = false
            tenPercentTipButton.isSelected = false
            
            costBrain.setTips(tip: 0.2)
        }
       
    }
    
    @IBAction func stepperValueChanged(_ sender: UIStepper) {
        
        costBrain.person = Int(sender.value)
        
        
    }
    
    @IBAction func calculatePressed(_ sender: UIButton) {
        
        
        costBrain.setCost(cost:Float(billTextField.text!) ?? 0)
        
        costBrain.calculateCost()
        
      
      
        
        
        self.performSegue(withIdentifier: "goToResult", sender: self)
        print(finishCost)
        
    }
    
    
    override func  prepare(for segue: UIStoryboardSegue, sender: Any?){
        if segue.identifier == "goToResult"{
            let destinationVC = segue.destination as! ResultsViewController
            
            destinationVC.result = costBrain.getResult()
            
        }
    }
    
    
    
}

