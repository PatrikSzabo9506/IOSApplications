//
//  CostBrain.swift
//  Tipsy
//
//  Created by Patrik Szabo on 2021. 08. 09..
//  Copyright © 2021. The App Brewery. All rights reserved.
//

import Foundation
import UIKit



struct CostBrain {
    var result: Float
    var person: Int
    var tip: Float
    var cost: Float
    
    
    mutating func calculateCost()  {
        
        result = (cost + (cost * tip) / Float(person))
    
    }
    
     mutating func setPerson(person: Int)  {
        self.person = person
    }
    
    mutating func setTips(tip: Float){
        
        self.tip = tip
    }
    
    mutating func setCost(cost: Float){
        self.cost = cost
    }
    
    func getResult() -> Float {

        return result
    
    }
    
    
    
    
    
    
}
