//
//  Netflix_CloneApp.swift
//  Netflix_Clone
//
//  Created by Patrik Szabo on 2021. 11. 08..
//

import SwiftUI

@main
struct Netflix_CloneApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
