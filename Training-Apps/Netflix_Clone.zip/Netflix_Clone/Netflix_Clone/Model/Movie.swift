//
//  Movie.swift
//  Netflix_Clone
//
//  Created by Patrik Szabo on 2021. 11. 08..
//

import Foundation

struct Movie: Identifiable{
    
    var id: String
    var name: String
    var tumbnailUrl: URL
    var categories:[String]
    
    
    //Episodes
    var episodes: [Episode]?


    // Personalization
    
    var currentEpisode: CurrentEpisodeInfo?
    
    var defaultEpisodeInfo: CurrentEpisodeInfo
    
   

// Movie Detail View
    var year: Int
    var rating: String
    var numberOfSeasons: Int?
    
    var numberOfSeasonsDisplay:String{
        
        if let num = numberOfSeasons{
            return "\(num) Season"
        }
        else{
            return ""
        }
        
        
        
    }

    var promotionHeadLine: String?
    
    var episodeInfoDisplay: String{
        if let current = currentEpisode {
            return "S\(current.season):E\(current.espide) \(current.episodeName)"
        }
        else{
            return "S\(defaultEpisodeInfo.season):E\(defaultEpisodeInfo.espide) \(defaultEpisodeInfo.episodeName)"
        }
    }
    
    
    var episodeDescriptionDisplay: String{
        if let current = currentEpisode {
            return current.description
        }else{
            return defaultEpisodeInfo.description
        }
    }
    
    var creators: String
    var cast: String
    
    var moreLikeThisMovies: [Movie]
    
    var trailers: [Trailer]

}


struct CurrentEpisodeInfo: Hashable, Equatable{
    var episodeName: String
    var description: String
    var espide: Int
    var season: Int
}
