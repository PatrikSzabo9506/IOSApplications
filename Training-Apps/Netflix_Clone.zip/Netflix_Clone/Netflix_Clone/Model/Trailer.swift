//
//  Trailer.swift
//  Netflix_Clone
//
//  Created by Patrik Szabo on 2021. 11. 12..
//

import Foundation


struct Trailer: Identifiable, Hashable{
    
    var id:String = UUID().uuidString
    
    var name: String
    var videoURL: URL
    var thumbnailImageURL: URL
    
}
