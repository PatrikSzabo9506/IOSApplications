//
//  GlobalHelpers.swift
//  Netflix_Clone
//
//  Created by Patrik Szabo on 2021. 11. 08..
//

import Foundation
import SwiftUI

let exampleVideoURL = URL(string: "https://www.radiantmediaplayer.com/media/big-buck-bunny-360.mp4")!
let exampleImageURL = URL(string: "https://picsum.photos/300/104")!
let exampleImageURL2 = URL(string: "https://picsum.photos/300/105")!
let exampleImageURL3 = URL(string: "https://picsum.photos/300/106")!

var randomExampleImageURL :URL{
    return [exampleImageURL,exampleImageURL2,exampleImageURL3].randomElement() ?? exampleImageURL
}

let exampleTrailer1 = Trailer( name: "Season 3 Trailers", videoURL: exampleVideoURL, thumbnailImageURL:randomExampleImageURL)
let exampleTrailer2 = Trailer( name: "The Heroes Journey", videoURL: exampleVideoURL, thumbnailImageURL:randomExampleImageURL)
let exampleTrailer3 = Trailer( name: "Misterious", videoURL: exampleVideoURL, thumbnailImageURL:randomExampleImageURL)

let exampleTrailers = [exampleTrailer1, exampleTrailer2, exampleTrailer3]

let episode1 = Episode(name: "Hello Swift",
                       season: 1,
                       thumbnailImageURLString: "https://picsum.photos/300/104",
                       description: "I learn swiftUI under trainings",
                       length: 53,
                       videoURL: exampleVideoURL,
                       episodeNumber: 5
                        )

let episode2 = Episode(name: "Hello Swift",
                       season: 1,
                       thumbnailImageURLString: "https://picsum.photos/300/105",
                       description: "I learn swiftUI under trainings",
                       length: 82,
                       videoURL: exampleVideoURL,
                       episodeNumber: 13)


let episode3 = Episode(name: "Hello Swift",
                       season: 1,
                       thumbnailImageURLString: "https://picsum.photos/300/106",
                       description: "I learn swiftUI under trainings",
                       length: 70,
                       videoURL: exampleVideoURL,
                       episodeNumber: 32)


let episode4 = Episode(name: "Hello Swift",
                       season: 2,
                       thumbnailImageURLString: "https://picsum.photos/300/107",
                       description: "I learn swiftUI under trainings",
                       length: 53,
                       videoURL: exampleVideoURL,
                       episodeNumber: 5)

let episode5 = Episode(name: "Hello Swift",
                       season: 2,
                       thumbnailImageURLString: "https://picsum.photos/300/108",
                       description: "I learn swiftUI under trainings",
                       length: 82,
                       videoURL: exampleVideoURL,
                       episodeNumber: 13)


let episode6 = Episode(name: "Hello Swift",
                       season: 2,
                       thumbnailImageURLString: "https://picsum.photos/300/109",
                       description: "I learn swiftUI under trainings",
                       length: 70,
                       videoURL: exampleVideoURL,
                       episodeNumber: 32)


let episode7 = Episode(name: "Hello Swift",
                       season: 3,
                       thumbnailImageURLString: "https://picsum.photos/300/107",
                       description: "I learn swiftUI under trainings",
                       length: 53,
                       videoURL: exampleVideoURL,
                       episodeNumber: 5)

let episode8 = Episode(name: "Hello Swift",
                       season: 3,
                       thumbnailImageURLString: "https://picsum.photos/300/108",
                       description: "I learn swiftUI under trainings",
                       length: 82,
                       videoURL: exampleVideoURL,
                       episodeNumber: 13)


let episode9 = Episode(name: "Hello Swift",
                       season: 3,
                       thumbnailImageURLString: "https://picsum.photos/300/109",
                       description: "I learn swiftUI under trainings",
                       length: 70,
                       videoURL: exampleVideoURL,
                       episodeNumber: 32)



var allExampleEpisode = [episode1,episode2,episode3,episode4,episode5,episode6,episode7 ,episode8 ,episode9  ]



var exampleMovie1 = Movie(
    id: UUID().uuidString,
    name: "DARK",
    tumbnailUrl: URL(string: "https://picsum.photos/200/300")!,
    categories: ["Dystopian", "SCI_FI", "Warrior","Horror"],
    episodes: allExampleEpisode, defaultEpisodeInfo: exampleEpisodeInfo1,
    year: 2020,
    rating: "TV-MA",
    numberOfSeasons: 3,
    promotionHeadLine: "Watch Season 1 now",
    creators:"Patrik Szabo",
    cast:"Anita, Balázs, Patrik",
    moreLikeThisMovies: [exampleMovie2,exampleMovie3,exampleMovie4,exampleMovie5,exampleMovie5,exampleMovie6,exampleMovie7], trailers: exampleTrailers)

var exampleMovie2 = Movie(
    id: UUID().uuidString,
    name: "Tralvelers",
    tumbnailUrl: URL(string: "https://picsum.photos/200/306")!,
    categories: ["Dystopian", "SCI_FI", "Warrior","Horror"],
    defaultEpisodeInfo: exampleEpisodeInfo1,
    year:2020,
    rating: "TV-MA",
    numberOfSeasons: 2,
    promotionHeadLine: "episodes coming soon",
    creators:"Patrik Szabo",
    cast:"Anita, Balázs, Patrik",
    moreLikeThisMovies: [], trailers: exampleTrailers)

var exampleMovie3 = Movie(
    id: UUID().uuidString,
    name: "Community",
    tumbnailUrl: URL(string: "https://picsum.photos/200/301")!,
    categories: ["Dystopian", "SCI_FI", "Warrior","Horror"],
    defaultEpisodeInfo: exampleEpisodeInfo1,
    year: 2020,
    rating: "TV-MA",
    numberOfSeasons: 3,
    promotionHeadLine: "New episodes coming every week",
    creators:"Patrik Szabo",
    cast:"Anita, Balázs, Patrik",
    moreLikeThisMovies: [], trailers: exampleTrailers)

var exampleMovie4 = Movie(
    id: UUID().uuidString,
    name: "Alone",
    tumbnailUrl: URL(string: "https://picsum.photos/200/302")!,
    categories: ["Dystopian", "SCI_FI", "Warrior","Horror"],
    defaultEpisodeInfo: exampleEpisodeInfo1,
    year: 2020,
    rating: "TV-MA",
    numberOfSeasons: 4,
    promotionHeadLine: "New Season coming",
    creators:"Patrik Szabo",
    cast:"Anita, Balázs, Patrik",
    moreLikeThisMovies: [], trailers: exampleTrailers)

var exampleMovie5 = Movie(
    id: UUID().uuidString,
    name: "Hannibal",
    tumbnailUrl: URL(string: "https://picsum.photos/200/303")!,
    categories: ["Dystopian", "SCI_FI", "Warrior","Horror"],
    defaultEpisodeInfo: exampleEpisodeInfo1,
    year: 2020,
    rating: "TV-MA",
    numberOfSeasons: 5,
    creators:"Patrik Szabo",
    cast:"Anita, Balázs, Patrik",
    moreLikeThisMovies: [], trailers: exampleTrailers)

var exampleMovie6 = Movie(
    id: UUID().uuidString,
    name: "AfterLife",
    tumbnailUrl: URL(string: "https://picsum.photos/200/304")!,
    categories: ["Dystopian", "SCI_FI", "Warrior","Horror"],
    defaultEpisodeInfo: exampleEpisodeInfo1,
    year: 2020,
    rating: "TV-MA",
    numberOfSeasons: 6,
    creators:"Patrik Szabo",
    cast:"Anita, Balázs, Patrik",
    moreLikeThisMovies: [], trailers: exampleTrailers)

var exampleMovie7 = Movie(
    id: UUID().uuidString,
    name: "Lucifer",
    tumbnailUrl: URL(string: "https://picsum.photos/200/305")!,
    categories: ["Dystopian", "SCI_FI", "Warrior","Horror"],
    defaultEpisodeInfo: exampleEpisodeInfo1,
    year: 2020,
    rating: "TV-MA",
    numberOfSeasons: 7,
    creators:"Patrik Szabo",
    cast:"Anita, Balázs, Patrik",
    moreLikeThisMovies: [], trailers: exampleTrailers)

var exampleMovies :[Movie] {
    return   [exampleMovie1,exampleMovie2,exampleMovie3,exampleMovie4,exampleMovie5,exampleMovie5,exampleMovie6,exampleMovie7].shuffled()

}
let exampleEpisodeInfo1 = CurrentEpisodeInfo(episodeName: "Welocme home", description: "JOE had a hard discussion with his boss and he feels like he could be an IOS developer", espide: 3, season: 2)

extension LinearGradient{
    static var blackOpacityGradient = LinearGradient(
        gradient: Gradient(colors: [Color.black.opacity(0),
        Color.black.opacity(0.95)]),
        startPoint: .top,
        endPoint: .bottom
    )
    
}


extension String {
    func widthOfString(usingFont font: UIFont) -> CGFloat{
        let fontattributes = [NSAttributedString.Key.font: font]
        let size = self.size(withAttributes: fontattributes)
        return size.width
    }
}
