//
//  HomeView.swift
//  Netflix_Clone
//
//  Created by Patrik Szabo on 2021. 11. 08..
//

import SwiftUI

struct HomeView: View {
    var vm = HomeVM()
    
    var screen = UIScreen.main.bounds
    
    @State private var movieDetailToShow: Movie? = nil
    
    @State private var topRowSelection: HomeTopRow = .home
    @State private var homeGenre: HomeGenre = .AllGenres
    
    @State private var showGenreSelection = false
    @State private var showTopRowSelection = false
    
    
    var body: some View {
        ZStack{
            Color.black
                .edgesIgnoringSafeArea(.all)
            
            
            //main VStack
            ScrollView(showsIndicators: false) {
                LazyVStack {
                    
                    TopRowButtons(topRowSelection: $topRowSelection, homeGenre: $homeGenre, showGenreSelection: $showGenreSelection, showRowSelection: $showTopRowSelection)
                    
                    TopMoviePreview(movie: exampleMovie2)
                        .frame(width: screen.width)
                        .padding(.top, -110)
                        .zIndex(-1)
                    
                    
                    
                    HomeStack(vm: vm, topRowSelection: topRowSelection, movieDetailToShow: $movieDetailToShow)
                }
            }//main VStack
            
            if movieDetailToShow != nil {
                MovieDetail(movie: movieDetailToShow!, movieDetailToShow: $movieDetailToShow)
                    .animation(.easeIn)
                    .transition(.opacity)
            }
            
        }
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}

struct TopRowButtons: View {
    
    @Binding var topRowSelection: HomeTopRow
    @Binding var homeGenre: HomeGenre
    @Binding var showGenreSelection: Bool
    @Binding var showRowSelection: Bool
    
    var body: some View {
        
        switch topRowSelection {
        case .home:
            HStack {
                Button(action: {
                    topRowSelection = .home
                }, label: {
                    Image("netflix_logo")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 50)
                }).buttonStyle(PlainButtonStyle())
                
                Spacer()
                
                Button(action: {
                    topRowSelection = .twShows
                }, label: {
                    Text("TV Shows")
                        .foregroundColor(.white)
                }).buttonStyle(PlainButtonStyle())
                
                Spacer()
                
                Button(action: {
                    topRowSelection = .movies
                }, label: {
                    Text("Movies")
                        .foregroundColor(.white)
                }).buttonStyle(PlainButtonStyle())
                
                Spacer()
                
                Button(action: {
                    topRowSelection = .myList
                }, label: {
                    Text("My List")
                        .foregroundColor(.white)
                }).buttonStyle(PlainButtonStyle())
                
            }
                .padding(.leading, 10)
                .padding(.trailing, 30)
        case .myList, .twShows, .movies:
            HStack {
                Button(action: {
                    topRowSelection = .home
                }, label: {
                    Image("netflix_logo")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 50)
                }).buttonStyle(PlainButtonStyle())
                
                Spacer()
                
                HStack(spacing: 20) {
                    Button(action: {
                        showRowSelection = true
                    }, label: {
                        Text(topRowSelection.rawValue)
                            .font(.system(size: 18))
                            .foregroundColor(.white)
                        Image(systemName: "triangle.fill")
                            .font(.system(size: 10))
                            .rotationEffect(.degrees(180),anchor: .center)
                            .foregroundColor(.white)
                        
                }).buttonStyle(PlainButtonStyle())
                
                Button(action: {
                    showGenreSelection = true
                }, label: {
                    HStack {
                        Text(homeGenre.rawValue)
                            .font(.system(size: 12))
                            .foregroundColor(.white)
                        Image(systemName: "triangle.fill")
                            .font(.system(size: 6))
                            .rotationEffect(.degrees(180),anchor: .center)
                            .foregroundColor(.white)
                    }
                }).buttonStyle(PlainButtonStyle())
               
                    Spacer()
                }
                
               
                
            }
                .padding(.leading, 10)
                .padding(.trailing, 30)
            
            
       
            
        }
        
       
    }
}

enum HomeTopRow: String, CaseIterable{
    
    case home = "Home"
    case twShows = "TV Shows"
    case movies = "Movies"
    case myList = "MY List"
    
    
}

enum HomeGenre: String{
    case AllGenres = "AllGenres"
    case Action = "Actions"
    case Comedy = "Comedy"
    case Horror = "Horror"
    case Thriller = "Thriller"
}


