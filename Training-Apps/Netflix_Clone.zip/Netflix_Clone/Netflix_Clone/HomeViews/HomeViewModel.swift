//
//  HomeViewModel.swift
//  Netflix_Clone
//
//  Created by Patrik Szabo on 2021. 11. 08..
//

import Foundation


class HomeVM: ObservableObject{
    
    @Published var movies: [String: [Movie]] = [:]
    
    func getMovieforCategory(cat: String) -> [Movie]{
        return movies[cat] ?? []
    }
    
    public var allCategories: [String]{
        return movies.keys.map { String($0)}
    }
    
    init (){
        setupMovies()
    }
    
    
    
    func setupMovies(){
        movies["Trending now"] = exampleMovies
        movies["StandUp-Comedy"] = exampleMovies.shuffled()
        movies["Scifi"] = exampleMovies.shuffled()
        movies["Horror"] = exampleMovies.shuffled()
        movies["Family"] = exampleMovies.shuffled()
        movies["Anime"] = exampleMovies.shuffled()
        movies["Action"] = exampleMovies.shuffled()
    }
}
