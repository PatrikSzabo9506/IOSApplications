//
//  StandradHomeMovie.swift
//  Netflix_Clone
//
//  Created by Patrik Szabo on 2021. 11. 08..
//

import SwiftUI
import KingfisherSwiftUI

struct StandradHomeMovie: View {
    var movie: Movie
    var body: some View {
        KFImage(movie.tumbnailUrl)
            .resizable()
            .scaledToFill()
    }
}

struct StandradHomeMovie_Previews: PreviewProvider {
    static var previews: some View {
        StandradHomeMovie(movie: exampleMovie1)
           }
}
