//
//  ContentView.swift
//  Netflix_Clone
//
//  Created by Patrik Szabo on 2021. 11. 08..
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, world!")
            .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
