//
//  Dice_SwiftUIApp.swift
//  Dice_SwiftUI
//
//  Created by Patrik Szabo on 2021. 11. 03..
//

import SwiftUI

@main
struct Dice_SwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
