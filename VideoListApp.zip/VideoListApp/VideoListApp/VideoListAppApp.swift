//
//  VideoListAppApp.swift
//  VideoListApp
//
//  Created by Patrik Szabo on 2021. 07. 01..
//

import SwiftUI

@main
struct VideoListAppApp: App {
    var body: some Scene {
        WindowGroup {
            VideoListView()
        }
    }
}
