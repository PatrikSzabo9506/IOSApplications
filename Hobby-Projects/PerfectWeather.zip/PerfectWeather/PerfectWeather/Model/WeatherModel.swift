//
//  WeatherModel.swift
//  PerfectWeather
//
//  Created by Patrik Szabo on 2021. 11. 17..
//

import Foundation

struct WeatherModel{
    
    var name:String
    var weatherID: Int
    var temp: String
    var description: String
    
    
   
}





