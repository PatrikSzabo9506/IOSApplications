//
//  PerfectWeatherApp.swift
//  PerfectWeather
//
//  Created by Patrik Szabo on 2021. 11. 14..
//

import SwiftUI

@main
struct PerfectWeatherApp: App {
    var body: some Scene {
        WindowGroup {
            WeatherControllerView()
        }
    }
}
