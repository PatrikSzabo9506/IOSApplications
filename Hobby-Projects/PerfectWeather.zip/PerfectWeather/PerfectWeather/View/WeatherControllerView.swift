//
//  ContentView.swift
//  PerfectWeather
//
//  Created by Patrik Szabo on 2021. 11. 14..
//

import SwiftUI

struct WeatherControllerView: View {
    @ObservedObject var networkManaegr = NetworkManager()
    @State private var cityName = ""
    @State private var isDarkModePressed: Bool = false
    @State var cityNameValue: String = "Budapest"
    
    var body: some View {
        
        ZStack{
            BackgrundColor(choseMode: isDarkModePressed)
            
            VStack {
                HStack{
                    TextField("Please enter a city name", text: $cityName)
                        .frame( height: 40)
                        .foregroundColor(.black)
                        .background(Color.white)
                        .cornerRadius(20)
                        .multilineTextAlignment(.center)
                        .autocapitalization(.words)
                    
                    Button {
                        cityNameValue = cityName
                        networkManaegr.fetchData(cityName: cityName)
                        cityName = ""
                        
                    } label: {
                        Image(systemName: "magnifyingglass.circle.fill")
                            .font(.system(size: 40))
                    }
                }.padding()
                
                Spacer()
                
                Text(cityNameValue)
                    .font(.system(size: 50))
                
                Spacer()
                
                VStack{
                    DailyWeatherView(temp: networkManaegr.weatherModel.temp , weatherImage: networkManaegr.weatherImage, description: networkManaegr.weatherModel.description)
                    
                    }
                .onAppear{
                    self.networkManaegr.fetchData(cityName: cityNameValue)
                    
                }.padding(.horizontal, 10)
                Spacer()
                
                Spacer()
                
                Button {
                    isDarkModePressed = !isDarkModePressed
                } label: {
                    Text(isDarkModePressed ?  "Light Mode" : "Dark Mode" )
                        .font(.title)
                        .frame(minWidth: 150)
                        .background(BackgrundColor(choseMode: !isDarkModePressed))
                        .cornerRadius(20)
                }
                
            }
            .foregroundColor(.white)
        }
    }
    
    
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            WeatherControllerView()
        }
    }
    
    
    
    
    struct DailyWeatherView: View {
        
        var temp: String
        var weatherImage: String
        var description: String
       
        var body: some View {
            VStack{
                
                Image(systemName:weatherImage)
                    .font(.system(size: 120))
                
                Text("\(temp) °C")
                    .font(.system(size: 50))
                    .bold()
                
                Text(description)
            }
            .padding(.bottom, 20)
        }
    }
}

struct BackgrundColor: View {
    
    var choseMode: Bool
    var body: some View {
        Group{
            if choseMode == false{
                LinearGradient(gradient: Gradient(colors: [.blue, .white]), startPoint: .topLeading, endPoint: .bottomTrailing)
                    .ignoresSafeArea()
                
            }
            else{
                LinearGradient(gradient: Gradient(colors: [.black, .white]), startPoint: .topLeading, endPoint: .bottomTrailing)
                    .ignoresSafeArea()
            }
        }
    }
}
