//
//  NetworkManager.swift
//  PerfectWeather
//
//  Created by Patrik Szabo on 2021. 11. 17..
//

import Foundation

class NetworkManager: ObservableObject{
    
    @Published var weatherModel = WeatherModel(name: "Budapest", weatherID: 0, temp: "0",description: "")
    
    var weatherImage: String{
        
        switch weatherModel.weatherID {
            
        case 200...232:
            return "cloud.bolt.fill"
        case 300...321:
            return "cloud.drizzle.fill"
        case 500...531:
            return "cloud.rain.fill"
        case 600...622:
            return "cloud.snow.fill"
        case 701...781:
            return "tropicalstorm"
        case 800:
            return "sun.max.fill"
        case 801...804:
            return "cloud.fill"
        default:
            return "cloud.sun.fill"
            
        }
        
        
    }
    
    
    let weatherURL = "https://api.openweathermap.org/data/2.5/weather?appid=e79c7391bb25639f4f3ed22d9f1e0cac&units=metric&q=Budapest"
    
    
    func fetchData(cityName: String){
        
        if let url = URL(string: "https://api.openweathermap.org/data/2.5/weather?appid=e79c7391bb25639f4f3ed22d9f1e0cac&units=metric&q=\(cityName)"){
            
            let session = URLSession(configuration: .default)
            let task = session.dataTask(with: url) { (data, response, error) in
                
                if error == nil{
                    
                    let decoder = JSONDecoder()
                    
                    if let safeData = data {
                        
                        do{
                       let result = try decoder.decode(WeatherData.self, from: safeData)
                           
                            DispatchQueue.main.async {
                                
                                self.weatherModel.temp = String(format:"%.1f",result.main.temp)
                                self.weatherModel.name = result.name
                                self.weatherModel.weatherID = result.weather[0].id
                                self.weatherModel.description = result.weather[0].description
                                
                            }
                            
                            
                        }
                        catch{
                            print(error)
                        }
                    }
                    
                    
                }
                
                
            }
            task.resume()
            
        }
        
        
        
    }
    
    
}
