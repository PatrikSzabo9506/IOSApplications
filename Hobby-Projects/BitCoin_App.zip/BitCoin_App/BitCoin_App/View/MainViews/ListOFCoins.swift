//
//  ListOFCoins.swift
//  BitCoin_App
//
//  Created by Patrik Szabo on 2022. 04. 26..
//

import SwiftUI

struct ListOFCoins: View {
    @ObservedObject var networkManager = NetworkManager()
    
    var body: some View {
        
        ZStack {
            BackGround()
            
            VStack {
                Text("Top 10 Coins")
                    .font(.title)
                    .foregroundColor(.white)
                
                CoinList()
            }
            
            
            
            
        }
        
        
    }
    
    
}
struct ListOFCoins_Previews: PreviewProvider {
    static var previews: some View {
        ListOFCoins()
            .preferredColorScheme(.light)
            .previewInterfaceOrientation(.portrait)
    }
}
