//
//  ContentView.swift
//  BitCoin_App
//
//  Created by Patrik Szabo on 2022. 04. 23..
//

import SwiftUI

struct HomeView: View {
    var body: some View {
        
        NavigationView{
            
            ZStack{
                LinearGradient(gradient: Gradient(colors: [Color.blue,Color.black]), startPoint: .topLeading, endPoint: .bottomTrailing)
                    .ignoresSafeArea()
                
                Image("gradient")
                    .edgesIgnoringSafeArea(.all)
                    .scaledToFill()
                    .frame(maxWidth:473,maxHeight: 494)
                
                
                VStack {
                    ZStack {
                        Image("card1")
                            .resizable()
                            .frame(maxWidth: 269, maxHeight: 354)
                        
                        Image("card2")
                            .resizable()
                            .frame(maxWidth: 390, maxHeight: 430)
                        
                    }
                    
                    Spacer()
                    
                    
                    VStack(spacing:20) {
                        Text("Start looking Crypto Currencies")
                            .font(.largeTitle).bold()
                            .frame( alignment: .leading)
                            .foregroundColor(.white)
                        
                        
                        
                        HStack(spacing:25) {
                            NavigationLink(destination: ListOFCoins()){
                                Image("button1")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(maxWidth: 162, maxHeight: 61)
                            }
                            
                            
                            Image("apple")
                                .scaledToFit()
                                .frame(maxWidth: 61, maxHeight: 61)
                            
                            Image("google")
                                .resizable()
                                .scaledToFit()
                                .frame(maxWidth: 61, maxHeight: 61)
                            
                            
                        }
                        .padding()
                    }
                    
                    
                    Spacer()
                }
                .padding()
                
            }
            .toolbar {
                // Here add the Bitcoin text in the top
                ToolbarItem(placement: .navigationBarLeading){
                    Text("Crypto")
                        .font(.largeTitle).bold()
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .foregroundColor(.white)
                }
            }
            
        }.ignoresSafeArea()
        
        
        
        
        
        
        
        
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            HomeView()
                .preferredColorScheme(.light)
                .previewInterfaceOrientation(.portrait)
            HomeView()
                .preferredColorScheme(.light)
        }
        
    }
}
