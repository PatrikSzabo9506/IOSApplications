//
//  OverView.swift
//  BitCoin_App
//
//  Created by Patrik Szabo on 2022. 04. 24..
//

import SwiftUI
import SwiftUICharts

struct OverView: View {
    
    @State var coin: CoinModel
    
    var body: some View {
        
        
        ZStack{
            
            Color.black
                .edgesIgnoringSafeArea(.all)
            
            Image("OverViewGradient")
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.all)
            
            
            VStack{
                Spacer()
                
                ChartView(coin: coin)
                
                OverViewDataView(date: coin.athDate!, name: coin.name, cost: coin.currentPrice, lost: coin.priceChange24H!)
                
                CoinPriceAndImageView(imageUrl: coin.image, cost: coin.currentPrice)
                
                Spacer()
                
                
                DailyLowestHighest(lowest: coin.low24H, highest: coin.high24H)
                    .padding(.horizontal)
                
                Spacer()
                
                
            }.padding()
                .toolbar {
                    ToolbarItem(placement: .navigationBarTrailing) { // add the logo top let corner
                        AsyncImage(url: URL(string: coin.image)!){image in
                            image.resizable()
                                .frame(maxWidth: 25, maxHeight: 25)
                        }placeholder: {
                            Image("btc")
                                .frame(maxWidth: 25, maxHeight: 25)
                        }
                    }
                }
            
        }
    }
}



struct OverView_Previews: PreviewProvider {
    static var previews: some View {
        OverView(coin: coinModel)
            .previewInterfaceOrientation(.portrait)
    }
}


extension StringProtocol {
    func slice(_ start: Int, _ end: Int) -> SubSequence {
        let lower = index(self.startIndex, offsetBy: start)
        let upper = index(lower, offsetBy: end - start)
        return self[lower...upper]
    }
}

struct DailyLowestHighest: View {
    var lowest: Double?
    var highest: Double?
    
    var body: some View {
        HStack{
            
            VStack{
                HStack {
                    Text("Daily lowest")
                        .foregroundColor(.white)
                    .font(.caption)
                    
                    Image(systemName: "arrow.down")
                        .foregroundColor(.red)
                        .frame(maxWidth:20,maxHeight: 20 )
                    
                }
                
                
                
                Text("\(lowest ?? 0, specifier: "%.2f")")
                    .foregroundColor(.white)
                    .bold()
            }
            
            Spacer()
            
            VStack{
                HStack {
                    Text("Daily Highest")
                        .foregroundColor(.white)
                    .font(.caption)
                    Image(systemName: "arrow.up")
                        .foregroundColor(.green)
                        .frame(maxWidth:20,maxHeight: 20 )

                }
                
                Text("\(highest ?? 0, specifier: "%.2f")")
                    .foregroundColor(.white)
                    .bold()
            }
            
        }
    }
}
