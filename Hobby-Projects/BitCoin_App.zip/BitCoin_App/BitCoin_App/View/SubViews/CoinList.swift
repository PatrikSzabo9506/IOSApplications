//
//  CoinList.swift
//  BitCoin_App
//
//  Created by Patrik Szabo on 2022. 05. 02..
//

import SwiftUI

struct CoinList: View {
    
    @ObservedObject var networkManager = NetworkManager()
    
    var body: some View {
        ScrollView{
            
            VStack {
                ForEach(networkManager.coinData){coin in
                    
                    NavigationLink(destination: OverView(coin: coin) ){
                        HStack(spacing: 20) {
                            AsyncImage(url: URL(string: coin.image)) {image in
                                image.resizable()
                                    .scaledToFit()
                                    .frame(maxWidth: 50, maxHeight:50)
                            }placeholder: {
                                Image("btc")
                            } // end of placeholrder Async image
                            
                            Text(coin.name)
                                .foregroundColor(.white)
                                .bold()
                                .listRowSeparatorTint(.black)
                            
                            Spacer()
                            
                            VStack {
                                
                                HStack {
                                    
                                    Image(systemName: (coin.priceChange24H ?? 0) > 0 ? "arrow.up" :"arrow.down")
                                    
                                    Text("\(coin.currentPrice ,specifier: "%.2f")$")
                                        .bold()
                                    
                                }.foregroundColor(coin.priceChange24H ?? 0 > 0 ? .green : .red)
                                
                                
                                Text("\(coin.priceChange24H ?? 0.0,specifier:"%.2f")$")
                                    .font(.caption2)
                                    .foregroundColor(coin.priceChange24H! >= 0 ? .green : .red)
                                    .frame(alignment: .trailing)
                                
                            }
                            
                            
                        }
                        .padding()
                    }
                }
            }
            
        }
        
    }
}

struct CoinList_Previews: PreviewProvider {
    static var previews: some View {
        CoinList()
    }
}
