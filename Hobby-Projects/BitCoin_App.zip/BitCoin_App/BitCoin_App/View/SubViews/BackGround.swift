//
//  BackGround.swift
//  BitCoin_App
//
//  Created by Patrik Szabo on 2022. 04. 23..
//

import SwiftUI

struct BackGround: View {
    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color(UIColor(named: "OverView1")!), Color(UIColor(named: "OverView2")!), Color.black]), startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
        }
     //   .edgesIgnoringSafeArea(.all)
    }
}

struct BackGround_Previews: PreviewProvider {
    static var previews: some View {
        BackGround()
    }
}
