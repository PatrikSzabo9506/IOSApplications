//
//  OverViewDataView.swift
//  BitCoin_App
//
//  Created by Patrik Szabo on 2022. 05. 02..
//

import SwiftUI

struct OverViewDataView: View {
    
    @State var date: String = " "
    @State var name: String = " "
    @State var cost: Double = 0.0
    @State var lost: Double = 0.0
    
    var body: some View {
        VStack{
            
            HStack {
                Text(name)
                    .font(.title).bold()
                    .foregroundColor(.white)
                
                Spacer()
                
            }
            .padding()
            
     
       
            Text(date.slice(0, 9))
                .font(.caption)
                .foregroundColor(.white)
                .opacity(0.7)
            Text("\(cost, specifier: "%.2f")$")
                .font(.largeTitle).bold()
                .foregroundColor(.white)
            
            
            Text("\(lost, specifier: "%.2f")$")
                .foregroundColor(lost >= 0 ? .green : .red)
                .bold()
                
        }
    }
}

struct OverViewDataView_Previews: PreviewProvider {
    static var previews: some View {
        OverViewDataView(date: "00", name: "Bitcoin", cost: 0.0, lost: 0.0)
    }
}
