//
//  ChartView.swift
//  BitCoin_App
//
//  Created by Patrik Szabo on 2022. 05. 03..
//

import SwiftUI
import SwiftUICharts

struct ChartView: View {
    
   var chartData: [Double] = [1,2,3]
    let maxY: Double
    let minY: Double
    let midY: Double
    let lineColor: Color
    let startDate : Date
    let endDate : Date
    
    @State private var percentage: CGFloat = 0
    
    
    init(coin: CoinModel){
        chartData = coin.sparklineIn7D?.price ?? []
        maxY = chartData.max() ?? 0
        minY = chartData.min() ?? 0
        midY = (maxY-minY) / 2 + minY
        
        let priceChange = (chartData.last ?? 0) - (chartData.first ?? 0)
        
        // here you can change the color of the line(if positive then green else red)
        lineColor = priceChange > 0 ? Color.green : Color.red
        
        endDate = Date(from: coin.lastUpdated ?? "")
        startDate = endDate.addingTimeInterval(-7*24*60*60)
        
    }
    
    var body: some View {
        
        VStack{
            chartView
                .frame(maxWidth:396, maxHeight: 189)
                .background(backGround)
                .overlay(chartYAxis.padding(.horizontal,4)
                         ,alignment: .leading)
            
            chartLabel.padding(.horizontal,4)
           
        }
        .font(.caption)
        .foregroundColor(Color.white)
        .onAppear{
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.50){
                withAnimation(.linear(duration: 3.00)){
                    percentage = 1.0
                }
                
            }
        }
      
}
}

struct ChartView_Previews: PreviewProvider {
    static var previews: some View {
        ChartView(coin: coinModel)
    }
}



extension ChartView{
    
    private var chartView: some View{
        GeometryReader { geometry in
            Path{ path in
                
                for index in chartData.indices{
                    
                    let xPos = geometry.size.width / CGFloat(chartData.count) *  CGFloat(index+1)
                    
                    let yAxis = maxY-minY
                    
                    let yPostion = (CGFloat(1 - (chartData[index] - minY) / yAxis)) * geometry.size.height
                    
                    
                    if index == 0{
                        path.move(to: CGPoint(x: xPos, y: yPostion))
                    }
                    path.addLine(to: CGPoint(x: xPos, y: yPostion))
                    
                    
                }
                
                
            }
            .trim(from: 0, to: percentage)
            .stroke(lineColor, style: StrokeStyle(lineWidth: 3, lineCap: .round, lineJoin: .round))
            .shadow(color: lineColor, radius: 10, x: 0, y: 10)
            .shadow(color: lineColor.opacity(0.5), radius: 10, x: 0, y: 20)
            .shadow(color: lineColor.opacity(0.2), radius: 10, x: 0, y: 30)
            .shadow(color: lineColor.opacity(0.1), radius: 10, x: 0, y: 40)
        }
    }
    
    
    var backGround: some View{
        VStack{
            Divider()
            Spacer()
            Divider()
            Spacer()
            Divider()
        }
    }
    
    private var chartYAxis: some View{
        VStack{
            Text("\(maxY, specifier: "%.0f")")
            Spacer()
            Text("\(midY, specifier: "%.0f")")
            Spacer()
            Text("\(minY, specifier: "%.0f")")
        }
    }
    
    private var chartLabel: some View{
        
        
        HStack{
            Text(startDate.asShortFormatterString())
            Spacer()
            Text(endDate.asShortFormatterString())
        }
    }
    
}

