//
//  CoinPriceAndImageView.swift
//  BitCoin_App
//
//  Created by Patrik Szabo on 2022. 05. 02..
//

import SwiftUI

struct CoinPriceAndImageView: View {
    
    @State var imageUrl: String = " "
    @State var cost: Double = 0.0
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 40)
                .frame(maxWidth:340,maxHeight: 83)
                .foregroundColor(.white)
                .opacity(0.08)
            
            HStack {
                
                AsyncImage(url: URL(string: imageUrl)){image in
                    
                    image.resizable()
                        .frame(maxWidth:34, maxHeight:34)
                        .foregroundColor(.white)
                    
                }
            placeholder:{
                Image(systemName: "bitcoinsign.circle.fill")
                    .foregroundColor(.white)
                    .font(.title)
            }
                
                
                
                Spacer()
                
                Text("cost: \(cost, specifier: "%.2f")$")
                    .foregroundColor(.white)
                    .bold()
                
            }.padding(40)
            
        }
    }
}

struct CoinPriceAndImageView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            CoinPriceAndImageView()
                .preferredColorScheme(.dark)
            
        }
    }
}
