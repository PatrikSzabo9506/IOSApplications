//
//  Date.swift
//  BitCoin_App
//
//  Created by Patrik Szabo on 2022. 05. 03..
//

import Foundation


extension Date {
    
    
    init(from coinGeckoString: String){
        
        let formatter = DateFormatter()
        
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
        let date = formatter.date(from: coinGeckoString) ?? Date()
        
        self.init(timeInterval: 0, since: date)
        
    }
    
    private var shorFormatter: DateFormatter{
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        return formatter
    }
    
    func asShortFormatterString() -> String{
        
        return shorFormatter.string(from: self)
    }
    
}
