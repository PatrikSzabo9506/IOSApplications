//
//  CoindModel.swift
//  BitCoin_App
//
//  Created by Patrik Szabo on 2022. 04. 26..
//




// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let welcome = try? newJSONDecoder().decode(Welcome.self, from: jsonData)

import Foundation

// MARK: - Welcome
struct CoinModel: Codable,Identifiable {
    let id, symbol, name: String
    let image: String
    let currentPrice: Double
    let  marketCap, marketCapRank, fullyDilutedValuation: Double?
    let totalVolume, high24H, low24H: Double?
    let priceChange24H, priceChangePercentage24H: Double?
    let marketCapChange24H: Double?
    let marketCapChangePercentage24H: Double?
    let circulatingSupply, totalSupply, maxSupply, ath: Double?
    let athChangePercentage: Double?
    let athDate: String?
    let atl, atlChangePercentage: Double?
    let atlDate: String?
    let lastUpdated: String?
    let sparklineIn7D: SparklineIn7D?
    let priceChangePercentage24HInCurrency: Double?

  enum CodingKeys: String, CodingKey {
        case id, symbol, name, image
        case currentPrice = "current_price"
        case marketCap = "market_cap"
       case marketCapRank = "market_cap_rank"
        case fullyDilutedValuation = "fully_diluted_valuation"
        case totalVolume = "total_volume"
        case high24H = "high_24h"
        case low24H = "low_24h"
        case priceChange24H = "price_change_24h"
        case priceChangePercentage24H = "price_change_percentage_24h"
        case marketCapChange24H = "market_cap_change_24h"
        case marketCapChangePercentage24H = "market_cap_change_percentage_24h"
        case circulatingSupply = "circulating_supply"
        case totalSupply = "total_supply"
        case maxSupply = "max_supply"
        case ath
        case athChangePercentage = "ath_change_percentage"
        case athDate = "ath_date"
        case atl
        case atlChangePercentage = "atl_change_percentage"
        case atlDate = "atl_date"
        case lastUpdated = "last_updated"
        case sparklineIn7D = "sparkline_in_7d"
        case priceChangePercentage24HInCurrency = "price_change_percentage_24h_in_currency"
    }
}

// MARK: - SparklineIn7D
struct SparklineIn7D: Codable {
    let price: [Double]?
}
//


// sample data


let coinModel = CoinModel(id: "bitcoin", symbol: "btc", name: "Bitcoin", image: "https://assets.coingecko.com/coins/images/1/large/bitcoin.png?1547033579", currentPrice: 40408, marketCap: 768537918492, marketCapRank: 1, fullyDilutedValuation: 848422201724, totalVolume: 29207260045, high24H: 40669, low24H: 38452, priceChange24H: 1878.92, priceChangePercentage24H: 4.87667, marketCapChange24H: 35020340505, marketCapChangePercentage24H: 4.7743, circulatingSupply: 19022718, totalSupply: 21000000, maxSupply: 21000000, ath: 69045, athChangePercentage: -41.49764, athDate: "2021-11-10T14:24:11.849Z", atl: 67.81, atlChangePercentage: 59468.51786, atlDate: "2013-07-06T00:00:00.000Z", lastUpdated: "2022-04-26T10:30:37.306Z", sparklineIn7D: spark7line, priceChangePercentage24HInCurrency: 4.87666929328847)


let spark7line = SparklineIn7D(price: data)

let data = [40710.36469539432,
            40772.30758656391,
            40670.419228623265,
            40753.0427173262,
            40645.731265218106,
            40771.47594082995,
            40774.029228923566,
            40997.694520011195,
            41381.63440076333,
            41602.00541791229,
            41480.81541326771,
            41363.551613475705,
            41316.229074761766,
            41398.49960954603,
            41313.05839370305,
            41303.73287410265,
            41332.03224032712,
            41424.506606684474,
            41498.12244669832,
            41355.744546037386,
            41382.588414759244,
            41381.757760112996,
            41401.381838143665,
            41342.17307170415,
            41437.26760910667,
            41458.43320759279,
            41365.73376164842,
            41520.55496691223,
            41589.890499264155,
            41830.33548180861,
            42004.49863668162,
            42127.85582858828,
            41600.54228853748,
            41458.5084143636,
            41284.923660789565,
            41389.22287682996,
            41369.54897096751,
            40983.01311833181,
            41219.08808990012,
            41437.34570362472,
            41529.35246090751,
            41498.59604332418,
            41395.06653501401,
            41555.61187973008,
            41699.057490247746,
            41640.39228338689,
            41675.23962130542,]

/*
 
 "id": "bitcoin",
 "symbol": "btc",
 "name": "Bitcoin",
 "image": "https://assets.coingecko.com/coins/images/1/large/bitcoin.png?1547033579",
 "current_price": 40408,
 "market_cap": 768537918492,
 "market_cap_rank": 1,
 "fully_diluted_valuation": 848422201724,
 "total_volume": 29207260045,
 "high_24h": 40669,
 "low_24h": 38452,
 "price_change_24h": 1878.92,
 "price_change_percentage_24h": 4.87667,
 "market_cap_change_24h": 35020340505,
 "market_cap_change_percentage_24h": 4.7743,
 "circulating_supply": 19022718,
 "total_supply": 21000000,
 "max_supply": 21000000,
 "ath": 69045,
 "ath_change_percentage": -41.49764,
 "ath_date": "2021-11-10T14:24:11.849Z",
 "atl": 67.81,
 "atl_change_percentage": 59468.51786,
 "atl_date": "2013-07-06T00:00:00.000Z",
 "roi": null,
 "last_updated": "2022-04-26T10:30:37.306Z",
 "sparkline_in_7d": {
   "price": [
     40710.36469539432,
     40772.30758656391,
     40670.419228623265,
     40753.0427173262,
     40645.731265218106,
     40771.47594082995,
     40774.029228923566,
     40997.694520011195,
     41381.63440076333,
     41602.00541791229,
     41480.81541326771,
     41363.551613475705,
     41316.229074761766,
     41398.49960954603,
     41313.05839370305,
     41303.73287410265,
     41332.03224032712,
     41424.506606684474,
     41498.12244669832,
     41355.744546037386,
     41382.588414759244,
     41381.757760112996,
     41401.381838143665,
     41342.17307170415,
     41437.26760910667,
     41458.43320759279,
     41365.73376164842,
     41520.55496691223,
     41589.890499264155,
     41830.33548180861,
     42004.49863668162,
     42127.85582858828,
     41600.54228853748,
     41458.5084143636,
     41284.923660789565,
     41389.22287682996,
     41369.54897096751,
     40983.01311833181,
     41219.08808990012,
     41437.34570362472,
     41529.35246090751,
     41498.59604332418,
     41395.06653501401,
     41555.61187973008,
     41699.057490247746,
     41640.39228338689,
     41675.23962130542,
     41618.85148827522,
     41490.85189498064,
     41555.78863506181,
     41921.83019958124,
     41896.03431651688,
     41825.00419550746,
     42342.65428147616,
     42483.449871709876,
     42736.0131595036,
     42646.69422998847,
     42472.22110484879,
     42123.543381944044,
     41927.99498889407,
     41582.35127678326,
     41535.919162818354,
     41320.202237803394,
     40701.25028798833,
     40759.36637555765,
     40351.572487267236,
     40528.54148675958,
     40430.87301981874,
     40540.98779817924,
     40498.16608604903,
     40550.87403324272,
     40623.155557459955,
     40667.360837760985,
     40688.513054036026,
     40665.95373976488,
     40416.52010640735,
     40320.9449603651,
     40448.50738915761,
     40575.76509412617,
     40429.02320346442,
     40325.363427456585,
     39919.47467560661,
     39413.396613485435,
     39404.73609885122,
     39396.30073132532,
     39512.63752885014,
     39565.44786723914,
     39642.550699505315,
     39629.46660933603,
     39721.67732043213,
     39756.848993471016,
     39614.825707748016,
     39598.18604843851,
     39480.493787598854,
     39519.37830195697,
     39555.762374375634,
     39591.86429706561,
     39624.879744985126,
     39587.33618311677,
     39645.04896489609,
     39542.186403363834,
     39639.510185852836,
     39628.91978394624,
     39711.40221976155,
     39710.64353191374,
     39721.987826494464,
     39810.6738505409,
     39902.15681104142,
     39826.50682258243,
     39708.032812710444,
     39794.739469305634,
     39848.555782230294,
     39965.64029066706,
     39883.62057292186,
     39555.127522961484,
     39634.35749583104,
     39554.33090548626,
     39607.69013553075,
     39800.92829552194,
     39735.25701713998,
     39715.99921054646,
     39774.948250194175,
     39800.73725722634,
     39779.157294846176,
     39798.8055695275,
     39732.40081642796,
     39639.22284449216,
     39603.158610851635,
     39557.56912194276,
     39871.65192281465,
     39676.19175739608,
     39452.473885849075,
     39431.28173270334,
     39712.927279582254,
     39723.04849272919,
     39519.73301357415,
     39637.17562265662,
     39609.28805650617,
     39469.04986198146,
     38904.68590471888,
     39112.87698791491,
     39106.25216887878,
     39267.69379269713,
     39187.00818592091,
     39020.85933625262,
     38786.5485848544,
     38491.99823422119,
     38464.03012283743,
     38623.92437673991,
     38494.11918688704,
     38823.01104194875,
     38825.90727014534,
     38916.7595074775,
     39091.836084031565,
     39052.59809105465,
     39552.54189930119,
     39431.530590486145,
     40071.757297333585,
     40259.972691054565,
     40153.33140790298,
     40247.86486067018,
     40331.55140010046,
     40458.13158475881,
     40593.50206761354,
     40484.01385059145,
     40523.972320016604,
     40528.1980098304,
     40606.773834435895
   ]
 }

"price_change_percentage_24h_in_currency": 4.87666929328847
},
 
 */
