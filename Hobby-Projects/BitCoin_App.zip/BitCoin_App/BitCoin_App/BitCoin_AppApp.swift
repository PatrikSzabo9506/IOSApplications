//
//  BitCoin_AppApp.swift
//  BitCoin_App
//
//  Created by Patrik Szabo on 2022. 04. 23..
//

import SwiftUI

@main
struct BitCoin_AppApp: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
        }
    }
}
