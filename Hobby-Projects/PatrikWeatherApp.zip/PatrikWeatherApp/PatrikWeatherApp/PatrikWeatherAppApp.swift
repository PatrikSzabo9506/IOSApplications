//
//  PatrikWeatherAppApp.swift
//  PatrikWeatherApp
//
//  Created by Patrik Szabo on 2022. 01. 17..
//

import SwiftUI

@main
struct PatrikWeatherAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
