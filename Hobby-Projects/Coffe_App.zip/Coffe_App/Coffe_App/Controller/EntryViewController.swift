//
//  EntryViewController.swift
//  Coffe_App
//
//  Created by Szabo Patrik on 2022. 05. 14..
//

import UIKit

class EntryViewController: UIViewController {
    
    let button: UIButton = {
        
        let button = UIButton()
        
        button.frame = CGRect(x: 0, y: 0, width: 200, height: 100)
        button.setTitle("Start", for: .normal)
        
        button.backgroundColor = .black
        button.tintColor = .white
       
        return button
    }()
    
 

    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.addSubview(button)
       
        
        button.addTarget(self, action: #selector(loadTabBar), for: .touchUpInside)
        
        
       
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        button.center = view.center
        
    }
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    @objc func loadTabBar(){
        // create the tab bar
        let tabBarVC = UITabBarController()
        
        let vc1 = UINavigationController(rootViewController: ViewController())
        let vc2 = UINavigationController(rootViewController: FavoritesViewController())
        let vc3 = UINavigationController(rootViewController: SettingsViewController())
        
        vc1.title = "Home"
        vc2.title = "Favorites"
        vc3.title = "Settings"
        
        
        tabBarVC.setViewControllers([vc1, vc2, vc3], animated: false)
        
        tabBarVC.modalPresentationStyle = .fullScreen
        present(tabBarVC, animated: true)
        
        guard let items = tabBarVC.tabBar.items else{return}
        
        let images = ["house", "star" ,"gear" ]
        
      for x in 0..<items.count {
            
            items[x].image = UIImage(systemName: images[x])

            
        }
        
        
        
    }
    
    
    
   

}
