//
//  ViewController.swift
//  Coffe_App
//
//  Created by Szabo Patrik on 2022. 05. 13..
//

import UIKit

class ViewController: UIViewController {
    
    let header = HeaderView()
  

    let topView: UIStackView = {
        let top = UIStackView()
        
      //  top.backgroundColor = .blue
        top.translatesAutoresizingMaskIntoConstraints = false
        
        return top
    }()
    
    let middleView:UIStackView = {
       let middle = UIStackView()
    //    middle.backgroundColor = .red
        middle.translatesAutoresizingMaskIntoConstraints = false
        
        return middle
        
    }()
    
    let bottomView:UIStackView = {
       let middle = UIStackView()
 //       middle.backgroundColor = .red
        middle.translatesAutoresizingMaskIntoConstraints = false
        
        return middle
        
    }()
    
    
    
    let bearImage: UIImageView = {
       
        let image = UIImageView()
        image.image = UIImage(named: "bear_first")
        image.translatesAutoresizingMaskIntoConstraints = false
        image.contentMode = .scaleAspectFit
        return image
        
        
    }()
    
    
    let name: UITextView = {
       
        let name = UITextView()
        name.text = "Welcome in UIKit"
        name.font = UIFont.boldSystemFont(ofSize: 18)
        name.translatesAutoresizingMaskIntoConstraints = false
        name.textAlignment = .center
        name.textColor = .black
        name.backgroundColor = .white
        name.isEditable = false
        name.isScrollEnabled = false
        
        return name
        
    }()
    
    let descriptionView:UITextView = {
        
        let desc = UITextView()
        desc.text = "Everything is better in Swiftui. Easier to read modified and handled than ever been in UIKit and thats all what i can say about this"
        desc.font = UIFont.systemFont(ofSize: 13)
        desc.translatesAutoresizingMaskIntoConstraints = false
        desc.textAlignment = .center
        desc.textColor = .gray
        desc.backgroundColor = .white
        desc.isEditable = false
        desc.isScrollEnabled = false
        
        
        return desc
        
    }()
    

    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
       
        
        // this enable autolayout
        
        title = "Home"
        
      setupLayout()
        
        view.backgroundColor = .white
        
        
        
    
        
    }
   
    
    private func setupLayout(){
        

       //header
        
        view.addSubview(header)
        
        header.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
        header.leadingAnchor.constraint(equalTo: view.leadingAnchor,constant: 10).isActive = true
        header.trailingAnchor.constraint(equalTo: view.trailingAnchor).isActive = true
        header.heightAnchor.constraint(equalTo: view.heightAnchor,multiplier: 0.2).isActive = true
        
        
    }

}



