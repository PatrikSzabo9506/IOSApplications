//
//  TopBarView.swift
//  Coffe_App
//
//  Created by Szabo Patrik on 2022. 05. 14..
//

import Foundation
import UIKit



class HeaderView: UIView{
    
    let image: UIImageView = {
        let image = UIImageView(image: UIImage(named: "Profile"))
        image.contentMode = .scaleAspectFit
        image.frame = CGRect(x: 0, y: 0, width: 50, height: 50)
        image.translatesAutoresizingMaskIntoConstraints = false
        return image
    }()
    
    
    let label: UILabel = {
        let label = UILabel()
        label.text = "Hungary Budapest"
        label.textColor = .gray
        label.font = UIFont.systemFont(ofSize: 8)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    
    let stackView: UIStackView = {
        let stackView = UIStackView()
                stackView.axis = .vertical
                stackView.distribution = .equalCentering
                return stackView
    }()
   
    
   
    override init(frame: CGRect) {
        super.init(frame: frame)
      addSubview(stackView)
        
        setLayout()
        
    }

    required init?(coder aDecoder: NSCoder) {
      fatalError()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        
    }

    
    private func setLayout(){
        stackView.addSubview(image)
        stackView.addSubview(label)
    }
    
    
}
